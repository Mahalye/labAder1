import { displayLogin } from "./displayLogin.js";

export const app = document.getElementById("app");
export const DOMAIN = "http://127.0.0.1:3000";

displayLogin();
