import { app } from "./app.js";

export function clearApp() {
  app.innerHTML = "";
}
